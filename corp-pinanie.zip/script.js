$(document).ready(function () {
    // Header Menu 
    $('.mobile-menu-icon').click(function(){
        $('.header-left-block').slideDown();
    });
    $('.mobile-menu-icon-close').click(function(){
        $('.header-left-block').slideUp();
    });
    if(window.matchMedia('(max-width: 1024px)').matches){
        $('.header-menu li').click(function(){
            $('.header-left-block').css('display', 'none');
        });
    }
    
    // Tariff
    $('.set-card-gallery1').slick({
        infinite: true,
        fade: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        asNavFor: '.card-gallery-thumbs1'
    });
    $('.card-gallery-thumbs1').slick({
        vertical: true,
        arrows: false,
        infinite: true,
        swipeToSlide: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        asNavFor: '.set-card-gallery1'
    });
    $('.set-card-gallery2').slick({
        infinite: true,
        fade: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        asNavFor: '.card-gallery-thumbs2'
    });
    $('.card-gallery-thumbs2').slick({
        vertical: true,
        arrows: false,
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        asNavFor: '.set-card-gallery2'
    });
    $('.set-card-gallery3').slick({
        infinite: true,
        fade: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        asNavFor: '.card-gallery-thumbs3'
    });
    $('.card-gallery-thumbs3').slick({
        vertical: true,
        arrows: false,
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        asNavFor: '.set-card-gallery3'
    });
    // Tarif tabs
    $('.set-tab-nav-item').click(function () {
        var id = $(this).attr('data-tab'),
            content = $('.set-tab-content-item[data-tab="' + id + '"]');


        $('.set-tab-nav-item.active').removeClass('active');
        $(this).addClass('active');

        $('.set-tab-content-item.active').removeClass('active');
        content.addClass('active');
        $('.set-card-gallery1').slick("setPosition");
        $('.card-gallery-thumbs1').slick('setPosition');
        $('.set-card-gallery2').slick("setPosition");
        $('.card-gallery-thumbs2').slick('setPosition');
        $('.set-card-gallery3').slick("setPosition");
        $('.card-gallery-thumbs3').slick('setPosition');
    });

    // Menu tabs
    $('.menu-breakfast-wrapper .menu-nav-tab-item').click(function () {
        var id = $(this).attr('data-tab'),
            content = $('.menu-breakfast-wrapper .menu-content[data-tab="' + id + '"]');

        $('.menu-breakfast-wrapper .menu-nav-tab-item.active').removeClass('active');
        $(this).addClass('active');

        $('.menu-breakfast-wrapper .menu-content.active').removeClass('active');
        content.addClass('active');
    });

    $('.menu-dinner-wrapper .menu-nav-tab-item').click(function () {
        var id = $(this).attr('data-tab'),
            content = $('.menu-dinner-wrapper .menu-content[data-tab="' + id + '"]');

        $('.menu-dinner-wrapper .menu-nav-tab-item.active').removeClass('active');
        $(this).addClass('active');

        $('.menu-dinner-wrapper .menu-content.active').removeClass('active');
        content.addClass('active');
    });

    $('.menu-supper-wrapper .menu-nav-tab-item').click(function () {
        var id = $(this).attr('data-tab'),
            content = $('.menu-supper-wrapper .menu-content[data-tab="' + id + '"]');

        $('.menu-supper-wrapper .menu-nav-tab-item.active').removeClass('active');
        $(this).addClass('active');

        $('.menu-supper-wrapper .menu-content.active').removeClass('active');
        content.addClass('active');
    });

    $('.menu-breakfast-wrapper .menu-arrow-right').click(function(){
        var scroll = $('.menu-breakfast-wrapper .menu-content.active').scrollLeft();
        $('.menu-breakfast-wrapper .menu-content.active').animate({scrollLeft: scroll + 240}, 800);
    });
    $('.menu-breakfast-wrapper .menu-arrow-left').click(function(){
        var scroll = $('.menu-breakfast-wrapper .menu-content.active').scrollLeft();
        $('.menu-breakfast-wrapper .menu-content.active').animate({scrollLeft: scroll - 240}, 800);
    });

    $('.menu-dinner-wrapper .menu-arrow-right').click(function(){
        var scroll = $('.menu-dinner-wrapper .menu-content.active').scrollLeft();
        $('.menu-dinner-wrapper .menu-content.active').animate({scrollLeft: scroll + 240}, 800);
    });
    $('.menu-dinner-wrapper .menu-arrow-left').click(function(){
        var scroll = $('.menu-dinner-wrapper .menu-content.active').scrollLeft();
        $('.menu-dinner-wrapper .menu-content.active').animate({scrollLeft: scroll - 240}, 800);
    });

    $('.menu-supper-wrapper .menu-arrow-right').click(function(){
        var scroll = $('.menu-supper-wrapper .menu-content.active').scrollLeft();
        $('.menu-supper-wrapper .menu-content.active').animate({scrollLeft: scroll + 240}, 800);
    });
    $('.menu-supper-wrapper .menu-arrow-left').click(function(){
        var scroll = $('.menu-supper-wrapper .menu-content.active').scrollLeft();
        $('.menu-supper-wrapper .menu-content.active').animate({scrollLeft: scroll - 240}, 800);
    });

    $('.menu-drink-wrapper .menu-arrow-right').click(function(){
        var scroll = $('.menu-drink-wrapper .menu-content').scrollLeft();
        $('.menu-drink-wrapper .menu-content').animate({scrollLeft: scroll + 240}, 800);
    });
    $('.menu-drink-wrapper .menu-arrow-left').click(function(){
        var scroll = $('.menu-drink-wrapper .menu-content').scrollLeft();
        $('.menu-drink-wrapper .menu-content').animate({scrollLeft: scroll - 240}, 800);
    });

    // Sliders
    $('.our-clients-block').slick({
        infinite: true,
        slidesToShow: 4,
        responsive: [{
            breakpoint: 1024,
            settings: {
                infinite: true,
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 768,
            settings: {
                infinite: true,
                slidesToShow: 2,
            }
        }]
    });
    $('.testimonials-block').slick({
        infinite: true,
        slidesToShow: 1,
    });

    // Text
    $('.show-more').click(function () {
        $('.hidden-text').toggle();
        
    });

    // Popup
    $('.call-to-action').click(function () {
        $('.popup-wrapper').css('display', 'flex');
    });
    $('.close-form').click(function () {
        $('.popup-wrapper').css('display', 'none');
    });
    /* $('.popup-wrapper').click(function () {
        $(this).css('display', 'none');
    }); */
    $('.popup-wrapper').click(function(e){
        if ($('.popup-wrapper').has(e.target).length === 0) {
            $('.popup-wrapper').css('display', 'none');     
        }
    });
});